package com.example.quickcash;

import androidx.lifecycle.ViewModel;

public class LoginViewModel extends ViewModel {
}

Hello everyone!

This is just the blank repository for our group project in CSCi-3130.
More files and project templates will be added when we learn more about the project.